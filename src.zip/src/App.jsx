import {
  useEffect,
  useState,
  useMemo
} from "react";

import AiMode from "./pages/AiMode";

import {
  BrowserRouter,
  Routes,
  Route,
  Link,
  Navigate,
  useLocation,
} from "react-router-dom";

import { useNavigate } from "react-router-dom";

import axios from "axios";

import Login from "./pages/Login";
import Admin from "./pages/Admin";
import Checkout from "./pages/Checkout";
import Boutique from "./pages/Boutique";
import Orders from "./pages/Orders";
import Register from "./pages/Register";
import UserLogin from "./pages/UserLogin";
import PrivacyPolicy from "./pages/PrivacyPolicy";

import Conditions from "./pages/Conditions";
import Address from "./pages/Address";

import Success from "./pages/Success";

import Favorites from "./pages/Favorites";
import Account from "./pages/Account";

import ForgotPassword
from "./pages/ForgotPassword";

import Message from "./pages/Message";

import ResetPassword
from "./pages/ResetPassword";

import AdminMessages from "./pages/AdminMessages";

import ProductDetails from "./pages/ProductDetails";

import Promotions from "./pages/promotions";

import Paiement from "./pages/Paiement";

import Community from "./pages/Community";

import MyOrders
from "./pages/Myorders";

import AdminSocial from "./pages/AdminSocial";

import Coupons from "./pages/Coupons";

import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import {

  FaBoxOpen,

  FaWhatsapp,

  FaExclamationTriangle,

  FaStar,

  FaTruck,

  FaFire,

  FaCrown,

  FaMicrophone,

  FaCamera,

  FaGem,

  FaCheck,

  FaSpinner,

  FaRobot,

  FaCheckCircle

} from "react-icons/fa";

import {

  FaSearch,

  FaHome,

  FaThLarge,

  FaComments,

  FaShoppingCart,

  FaShoppingBag,

  FaUser,

  FaUserPlus

} from "react-icons/fa";

import {
  FaShieldAlt,
  FaFileContract,
  FaLock,
  FaHeadset,
} from "react-icons/fa";

import {
  FaHeart,
  FaUserCircle,
} from "react-icons/fa";

import { FaFireAlt } from "react-icons/fa";

import Messages from "./pages/Messages";

import PendingOrders from "./pages/PendingOrders";
import ShippedOrders from "./pages/ShippedOrders";
import DeliveredOrders from "./pages/DeliveredOrders";
import CancelledOrders from "./pages/CancelledOrders";

import OrderDetails
from "./pages/OrderDetails";

import TrackOrder from "./pages/TrackOrder";

import DriverTracking
from "./pages/DriverTracking";

import DriverRegister
from "./pages/DriverRegister";

import DriverLogin
from "./pages/DriverLogin";

import Drivers from "./pages/Drivers";

import AdminProducts
from "./pages/AdminProducts";

import AdminClients
from "./pages/AdminClients";

import AdminStats from "./pages/AdminStats";

import AdminOrders
from "./pages/AdminOrders";

import AdminSettings from "./pages/AdminSettings";

import AdminCoupons from "./pages/AdminCoupons";

import Deliveries from "./pages/Deliveries";

import SeoOrganization from "./components/SeoOrganization";

import SeoWebsite from "./components/SeoWebsite";
import SeoBreadcrumb from "./components/SeoBreadcrumb";
import SeoProduct from "./components/SeoProduct";

import KonanLoader from "./components/KonanLoader";

import PageLoader from "./components/PageLoader";

import InstallButton from "./components/InstallButton";

// ======================================================
// 🔐 PROTECTION FRONTEND ALIGNÉE SUR LE BACKEND
// ======================================================
// Le frontend bloque l'accès aux interfaces sensibles.
// Le backend reste l'autorité réelle et vérifie toujours les JWT.
// Aucun secret backend n'est stocké ici.

function readStoredJSON(key) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : null;
  } catch (_) {
    return null;
  }
}

function hasUserSession() {
  return Boolean(localStorage.getItem("token") && readStoredJSON("user"));
}

function hasAdminSession() {
  const token = localStorage.getItem("token");
  const admin = readStoredJSON("admin");
  return Boolean(token && admin && (admin.role === "admin" || admin.isAdmin === true));
}

function hasDriverSession() {
  const driver = readStoredJSON("driver");
  const driverToken = driver?.token || localStorage.getItem("driverToken");
  return Boolean(driverToken && driver);
}

function RequireUser({ children }) {
  return hasUserSession() ? children : <Navigate to="/login" replace />;
}

function RequireAdmin({ children }) {
  return hasAdminSession() ? children : <Navigate to="/admin-login" replace />;
}

function RequireDriver({ children }) {
  return hasDriverSession() ? children : <Navigate to="/driver-login" replace />;
}

function RequireUserOrAdmin({ children }) {
  return hasUserSession() || hasAdminSession() ? children : <Navigate to="/login" replace />;
}

function Home() {

  console.log("HOME RENDER");

  const navigate = useNavigate();

  const location = useLocation();

const [favoritesCount,
setFavoritesCount] =
useState(0);

const [clickSound] = useState(
  () => new Audio("/sounds/click.mp3")
);

const playSound = () => {

  clickSound.currentTime = 0;

  clickSound.volume = 0.5;

  clickSound.play().catch(() => {});

};

useEffect(() => {

  console.log("Effect 1");

  const updateFavorites =
    () => {

      const user =

        JSON.parse(
          localStorage.getItem(
            "user"
          )
        );

      const clientId =

        user?._id ||

        localStorage.getItem(
          "guestId"
        );

      const favoritesKey =
        `favorites_${clientId}`;

      const favorites =

        JSON.parse(
          localStorage.getItem(
            favoritesKey
          )
        ) || [];

      setFavoritesCount(
        favorites.length
      );

    };

  // LOAD INITIAL

  updateFavorites();

  // LIVE UPDATE

  window.addEventListener(
    "favoritesUpdated",
    updateFavorites
  );

  return () => {

    window.removeEventListener(
      "favoritesUpdated",
      updateFavorites
    );

  };

}, []);

const user =

  JSON.parse(
    localStorage.getItem(
      "user"
    )
  );

const clientId =

  user?._id ||

  localStorage.getItem(
    "guestId"
  );

// JWT uniquement pour les appels backend nécessitant l'identité du client.
const authToken = localStorage.getItem("token");
const authHeaders = authToken
  ? { Authorization: `Bearer ${authToken}` }
  : {};

const favoritesKey =
  `favorites_${clientId}`;

const [likedProducts, setLikedProducts] =
  useState([]);

useEffect(() => {

  console.log("Effect 2");

  const favorites =
    JSON.parse(
      localStorage.getItem(
        "favorites"
      )
    ) || [];

  setLikedProducts(
    favorites.map(
      (item) => item._id
    )
  );

}, []);

const admin =
  JSON.parse(
    localStorage.getItem(
      "admin"
    )
  );

const placeholders = [
  "Que recherchez-vous aujourd’hui ?",
  "Jordan 4",
  "Chemise",
  "Sac à dos",
  "Chaussures Nike",
  "Montre",
  "T-shirts",

  "🔥 Promotion Samsung -20%",

"📱 Nouveaux iPhone disponibles",

"👟 Découvrez nos Nike",

"⌚ Montres tendance 2026",

"Creé un compte konanshopping",

"Béneficie de JUSQU A",

"5000FCFA OFFERT PREMIER ACHAT",

"🚚 Livraison rapide partout au Cameroun"

];

const [loading,
setLoading] =
useState(false);

const [placeholderIndex, setPlaceholderIndex] =
  useState(0);

useEffect(()=>{

  console.log("Effect 3");

 trackVisitor();

},[]);

const trackVisitor = async () => {

  // Ne pas exécuter en développement
  if (import.meta.env.DEV) return;

  try {

    const response = await fetch(
      "https://ipapi.co/json/"
    );

    if (!response.ok) {
      console.log("Impossible de récupérer la géolocalisation");
      return;
    }

    const geo = await response.json();

    console.log(geo);

    await axios.post(
      "https://konanshopping.com/api/track-visitor",
      {
        ip: geo.ip,
        country: geo.country,
        city: geo.city,
        device: navigator.userAgent,
      }
    );

  } catch (err) {

    console.log("Erreur suivi visiteur :", err);

  }

};

useEffect(() => {

  console.log("Effect 4");

  const interval = setInterval(() => {

    setPlaceholderIndex((prev) =>
      (prev + 1) % placeholders.length
    );

  }, 2000);

  return () => clearInterval(interval);

}, []);

const [image,setImage] =
useState(null);

const [showAlert, setShowAlert] =
  useState(false);

  const [showBottomNav, setShowBottomNav] = useState(true);

  // Header compact au scroll : on conserve toute la logique existante
  // et on change uniquement l'affichage du header selon la direction.
  const [compactHeader, setCompactHeader] = useState(false);

useEffect(() => {

  console.log("Effect 5");

  let scrollTimer;
  let lastScrollY = window.scrollY;

  // Distance cumulée de remontée avant de réafficher
  // le header complet. Cela évite qu'un petit mouvement
  // vers le haut donne l'impression que le header bug.
  let upwardScrollDistance = 0;

  const handleScroll = () => {

    const currentScrollY = window.scrollY;
    const delta = currentScrollY - lastScrollY;

    // =========================
    // HEADER PREMIUM AU SCROLL
    // =========================

    if (Math.abs(delta) >= 4) {

      // Le client descend : header compact
      if (currentScrollY > 70 && delta > 0) {
        upwardScrollDistance = 0;
        setCompactHeader(true);
      }

      // Le client remonte :
      // on attend une remontée significative
      // avant de réafficher tout le header.
      else if (delta < 0) {

        upwardScrollDistance += Math.abs(delta);

        if (
          upwardScrollDistance >= 80 ||
          currentScrollY <= 10
        ) {
          setCompactHeader(false);
          upwardScrollDistance = 0;
        }

      }

    }

    // Toujours afficher le header complet tout en haut
    if (currentScrollY <= 10) {
      setCompactHeader(false);
      upwardScrollDistance = 0;
    }

    lastScrollY = currentScrollY;

    // =========================
    // LE CLIENT SCROLL
    // =========================

    setShowBottomNav(false);

    // Annuler le précédent timer
    clearTimeout(scrollTimer);

    // =========================
    // ATTENDRE 5 SECONDES
    // SANS SCROLL
    // =========================

    scrollTimer = setTimeout(() => {

      setShowBottomNav(true);

    }, 5000);

  };

  window.addEventListener(
    "scroll",
    handleScroll,
    { passive: true }
  );

  return () => {

    window.removeEventListener(
      "scroll",
      handleScroll
    );

    clearTimeout(scrollTimer);

  };

}, []);

const [showWelcomePopup, setShowWelcomePopup] =
  useState(false);

useEffect(() => {

  console.log("Effect 6");

  // =====================
  // CLIENT CONNECTÉ ?
  // =====================

  const user = JSON.parse(
    localStorage.getItem("user")
  );

  if (user) return;

  // =====================
  // POPUP DÉJÀ AFFICHÉE ?
  // =====================

  const alreadySeen =
    sessionStorage.getItem(
      "welcomePopup"
    );

  if (alreadySeen) return;

  // =====================
  // AFFICHER APRÈS 5 SECONDES
  // =====================

  const timer = setTimeout(() => {

    setShowWelcomePopup(true);

    sessionStorage.setItem(
      "welcomePopup",
      "true"
    );

  }, 5000);

  return () =>
    clearTimeout(timer);

}, []);

const [aiProducts,
setAiProducts] =
useState([]);

  const [products, setProducts] =
  useState([]);

const [homeLoading, setHomeLoading] =
  useState(true);


    const randomizedProducts = useMemo(() => {

  if (products.length === 0) {
    return [];
  }

  // =========================
  // RETOUR DE PRODUCT DETAILS
  // =========================

  if (location.state?.productsOrder?.length) {

    const ids =
      location.state.productsOrder;

    return ids
      .map((id) =>
        products.find(
          (p) => p._id === id
        )
      )
      .filter(Boolean);
  }

  // =========================
  // NOUVELLE ARRIVÉE
  // =========================

  return [...products].sort(
    () => Math.random() - 0.5
  );

}, [
  products,
  location.state?.productsOrder
]);

    const [suggestions, setSuggestions] =
useState([]);

  const [cart, setCart] =
  useState(() => {

    const user =

      JSON.parse(
        localStorage.getItem(
          "user"
        )
      );

    const clientId =

      user?._id ||

      localStorage.getItem(
        "guestId"
      );

    const cartKey =
      `cart_${clientId}`;

    const savedCart =

      localStorage.getItem(
        cartKey
      );

    return savedCart
      ? JSON.parse(savedCart)
      : [];

  });

 const [search, setSearch] = useState("");
const [searchQuery, setSearchQuery] = useState("");
const [searchClicked, setSearchClicked] = useState(false);

const SpeechRecognition =
  window.SpeechRecognition ||
  window.webkitSpeechRecognition;

const recognition =
  SpeechRecognition
    ? new SpeechRecognition()
    : null;

if (recognition) {
  recognition.lang = "fr-FR";
}

const startVoice = () => {

  if (!recognition) {

    alert(
      "La recherche vocale n'est pas supportée sur cet appareil."
    );

    return;

  }

  try {

    recognition.start();

    recognition.onresult = (event) => {

      const text =
        event.results[0][0].transcript;

      setSearch(text);

    };

  } catch (err) {

    console.log(
      "Erreur recherche vocale :",
      err
    );

  }

};


  const [
    selectedCategory,
    setSelectedCategory
  ] = useState("Tous");

useEffect(() => {

  console.log("Effect 7");

  const loadProducts = async () => {

    try {

      // =========================
      // CACHE EXISTANT
      // =========================

      const cached =
        sessionStorage.getItem(
          "konan_home_products"
        );

      if (cached) {

        console.log(
          "PRODUITS RÉCUPÉRÉS DU CACHE"
        );

        setProducts(
          JSON.parse(cached)
        );

        setHomeLoading(false);

        return;
      }

      // =========================
      // PREMIÈRE CHARGE
      // =========================

      setHomeLoading(true);

      const res = await axios.get(
        "https://konanshopping.com/api/products"
      );

      const productsData =
        res.data;

      setProducts(
        productsData
      );

      // =========================
      // SAUVEGARDE CACHE
      // =========================

      sessionStorage.setItem(
        "konan_home_products",
        JSON.stringify(
          productsData
        )
      );

    }

    catch (err) {

      console.log(
        "Erreur chargement produits :",
        err
      );

    }

    finally {

      setHomeLoading(false);

    }

  };

  console.log("HOME MOUNT");

  loadProducts();

}, []);

useEffect(() => {

console.log("Effect 8");

  if (location.state?.scrollY != null) {
    requestAnimationFrame(() => {
      window.scrollTo({
        top: location.state.scrollY,
        behavior: "auto",
      });
    });
  }
}, [location]);

useEffect(() => {

  if (
    location.state?.visibleProducts
  ) {

    setVisibleProducts(
      location.state.visibleProducts
    );

  }

}, [location.state?.visibleProducts]);


  const [addedProduct, setAddedProduct] =
useState(null);

useEffect(() => {

  console.log("Effect 10");
  console.log("addedProduct =", addedProduct);
}, [addedProduct]);

  const addToCart = (product) => {

  const user =

    JSON.parse(
      localStorage.getItem(
        "user"
      )
    );

  // =====================
  // IDENTIFIANT CLIENT
  // =====================

  const clientId =

    user?._id ||

    localStorage.getItem(
      "guestId"
    ) ||

    (() => {

      const newGuestId =

        "guest_" +
        Date.now();

      localStorage.setItem(
        "guestId",
        newGuestId
      );

      return newGuestId;

    })();

  // =====================
  // PANIER PRIVÉ CLIENT
  // =====================

  const cartKey =
    `cart_${clientId}`;

  const existingProduct =

    cart.find(
      (item) =>
        item._id === product._id
    );

  let updatedCart = [];

  // =====================
  // PRODUIT EXISTE
  // =====================

  if (existingProduct) {

    updatedCart = cart.map(
      (item) =>

        item._id === product._id

          ? {

              ...item,

              quantity:
                (item.quantity || 1) + 1,

            }

          : item

    );

  }

  // =====================
  // NOUVEAU PRODUIT
  // =====================

  else {

    updatedCart = [

      ...cart,

      {

        ...product,

        quantity: 1,

      },

    ];

  }

  // =====================
  // UPDATE STATE
  // =====================

  setCart(updatedCart);

  // =====================
  // SAVE CLIENT CART
  // =====================

  localStorage.setItem(

    cartKey,

    JSON.stringify(
      updatedCart
    )

  );

  // =====================
  // UPDATE COUNT
  // =====================

  localStorage.setItem(

    "cartCount",

    updatedCart.length

  );

  // =====================
  // EVENT UPDATE
  // =====================

  window.dispatchEvent(
    new Event("cartUpdated")
  );

};

const [visibleProducts, setVisibleProducts] =
  useState(8);


useEffect(() => {

  console.log("Effect 11");

  const handleScroll = () => {

    console.log("scroll déclenché");
    console.log("visible :", visibleProducts);

    console.log(
      window.innerHeight +
      window.scrollY,
      document.documentElement.scrollHeight
    );

    if (
      window.innerHeight +
      window.scrollY >=
      document.documentElement.scrollHeight - 300
    ) {

      console.log("AJOUT DE 4 PRODUITS");

      setVisibleProducts(prev => prev + 4);

    }
  };

  window.addEventListener("scroll", handleScroll);

  return () =>
    window.removeEventListener("scroll", handleScroll);

}, [visibleProducts]);

useEffect(() => {

  console.log("Effect 12");

  const logScroll = () => {

    console.log("window scroll");

    console.log("scrollY :", window.scrollY);

    console.log("innerHeight :", window.innerHeight);

    console.log("body :", document.body.scrollHeight);

    console.log("document :", document.documentElement.scrollHeight);

  };

  window.addEventListener("scroll", logScroll);

  return () => window.removeEventListener("scroll", logScroll);

}, []);

const searchProducts =
async()=>{

  setSearchClicked(true);
setSearchQuery(search);

try{

setLoading(true);

// =====================
// SI IMAGE
// =====================

if(image){

const formData =
new FormData();

formData.append(
"image",
image
);

const res =
await axios.post(

"https://konanshopping.com/api/products/ai-search",

formData,

{ headers: authHeaders }

);

console.log(res.data);

setAiProducts(
res.data.products
);

}

// =====================
// SI TEXTE
// =====================

else if(search.trim() !== ""){

setSearchClicked(true);
setSearchQuery(search);

}

// =====================
// RIEN
// =====================

else{

  setShowAlert(true);

}

setLoading(false);

}

catch(err){

console.log(err);

setLoading(false);

}

};

if (
  homeLoading &&
  !location.state?.productsOrder
) {
  return <KonanLoader />;
}

  return (
  <>
  <SeoOrganization />
  <SeoWebsite />

  <SeoBreadcrumb
    items={[
      {
        name: "Accueil",
        url: "https://konanshopping.com",
      },
    ]}
  />

  <div
      style={{
        minHeight: "100vh",
        background: "#f5f5f7",
        fontFamily: "Arial",
        width: "100%",
        maxWidth: "100%",
      }}
    >

<input
  type="file"

  accept="image/*"

  id="imageUpload"

  style={{
    display: "none",
  }}

  onChange={(e) => {

    const file =
      e.target.files[0];

    setImage(file);

  }}
/>

    
{/* =========================================================
    HEADER FIXE — KONAN SHOPPING
========================================================= */}

<div
  style={{
    position: "fixed",
    top: 0,
    left: 0,
    right: 0,

    width: "100%",

    background: "rgba(255,255,255,0.97)",

    backdropFilter: "blur(20px)",
    WebkitBackdropFilter: "blur(20px)",

    borderBottom: "1px solid rgba(229,231,235,0.85)",

    zIndex: 9999,

    boxSizing: "border-box",

    // =========================
    // HEADER NORMAL / COMPACT
    // =========================

    padding: compactHeader
      ? (
          window.innerWidth < 768
            ? "6px 10px"
            : "7px 22px"
        )
      : (
          window.innerWidth < 768
            ? "8px 10px 9px"
            : "10px 22px 12px"
        ),

    maxHeight: compactHeader
      ? (
          window.innerWidth < 768
            ? "58px"
            : "68px"
        )
      : (
          window.innerWidth < 768
            ? "150px"
            : "110px"
        ),

    // IMPORTANT :
    // On laisse dépasser les suggestions de recherche afin
    // qu'elles ne soient pas coupées par le header fixe.
    overflow: "visible",

    transition:
      "max-height .42s cubic-bezier(.22,1,.36,1), " +
      "padding .32s ease, " +
      "box-shadow .32s ease",

    boxShadow: compactHeader
      ? "0 10px 28px rgba(15,23,42,0.11)"
      : "0 6px 24px rgba(15,23,42,0.07)",
  }}
>

  {/* =====================================================
      TOP BAR
  ===================================================== */}

  <div
    style={{
      display: "flex",

      alignItems: "center",

      justifyContent:
        window.innerWidth < 768
          ? "space-between"
          : "space-between",

      gap:
        window.innerWidth < 768
          ? "8px"
          : "14px",

      width: "100%",

      maxWidth: "1600px",

      margin: "0 auto",
    }}
  >

    {/* ===================================================
        LOGO
    =================================================== */}

    <Link
      to="/"
      style={{
        textDecoration: "none",

        display: "flex",

        alignItems: "center",

        gap: compactHeader
          ? "0"
          : (
              window.innerWidth < 768
                ? "6px"
                : "9px"
            ),

        flexShrink: 0,
      }}
    >

      <img
        src="/logo.jpg"
        alt="Konan Shopping"
        translate="no"

        style={{
          width:
            compactHeader
              ? (
                  window.innerWidth < 768
                    ? "34px"
                    : "40px"
                )
              : (
                  window.innerWidth < 768
                    ? "34px"
                    : "42px"
                ),

          height:
            compactHeader
              ? (
                  window.innerWidth < 768
                    ? "34px"
                    : "40px"
                )
              : (
                  window.innerWidth < 768
                    ? "34px"
                    : "42px"
                ),

          objectFit: "cover",

          borderRadius:
            window.innerWidth < 768
              ? "9px"
              : "11px",

          display: "block",

          boxShadow:
            "0 3px 10px rgba(75,46,131,0.12)",
        }}
      />

      <div
        style={{
          lineHeight: "1",

          display: "block",
          transition: "opacity .25s ease",
        }}
      >

        <div
          translate="no"
          style={{
            margin: 0,

            fontSize:
              window.innerWidth < 768
                ? "10px"
                : "13px",

            color: "#1F1B4B",

            fontWeight: "900",

            lineHeight: "1.05",

            letterSpacing: "-0.3px",
          }}
        >
          KONAN
        </div>

        <div
          translate="no"
          style={{
            margin: 0,

            fontSize:
              window.innerWidth < 768
                ? "10px"
                : "13px",

            color: "#5B3CC4",

            fontWeight: "900",

            lineHeight: "1.05",

            letterSpacing: "-0.3px",
          }}
        >
          SHOPPING
        </div>

      </div>

    </Link>


    {/* ===================================================
        DESKTOP SEARCH
        Sur mobile elle descend sur la deuxième ligne
    =================================================== */}

    {window.innerWidth >= 768 && !compactHeader && (

      <div
        style={{
          flex: 1,

          display: "flex",

          justifyContent: "center",

          minWidth: 0,

          margin:
            "0 15px",

          position: "relative",

          maxWidth: "620px",
        }}
      >

        <div
          style={{
            width: "100%",

            background: "#F8FAFC",

            position: "relative",

            borderRadius: "999px",

            display: "flex",

            alignItems: "center",

            overflow: "hidden",

            border:
              "1px solid #E5E7EB",

            boxShadow:
              "0 2px 8px rgba(15,23,42,0.04)",
          }}
        >

          <FaSearch
            style={{
              marginLeft: "16px",

              color: "#94A3B8",

              fontSize: "14px",

              flexShrink: 0,
            }}
          />

          <input
            type="text"

            placeholder={
              placeholders[placeholderIndex]
            }

            value={search}

            onChange={(e) => {

              const value =
                e.target.value;

              setSearch(value);

              if (value.trim()) {

                const filtered =
                  products.filter(
                    (product) =>
                      product.name
                        .toLowerCase()
                        .includes(
                          value.toLowerCase()
                        )
                  );

                setSuggestions(
                  filtered.slice(0, 5)
                );

              } else {

                setSuggestions([]);

              }

            }}

            onKeyDown={(e) => {

  if (
    e.key === "Enter" &&
    search.trim()
  ) {

    setSuggestions([]);

    searchProducts();

  }

}}

            style={{
              flex: 1,

              minWidth: 0,

              border: "none",

              outline: "none",

              padding:
                "12px 12px",

              fontSize: "14px",

              background:
                "transparent",

              color: "#111827",

              WebkitTextFillColor:
                "#111827",

              caretColor:
                "#4B2E83",
            }}
          />

<button
  type="button"
  onClick={(e) => {
    e.preventDefault();
    e.stopPropagation();

    if (!search.trim()) {
      return;
    }

    setSuggestions([]);

    searchProducts();
  }}
  style={{
    width: "42px",
    height: "42px",
    border: "none",
    background: "#4B2E83",
    color: "#FFFFFF",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
    cursor: "pointer",
    touchAction: "manipulation",
    WebkitTapHighlightColor: "transparent",
  }}
>
  {loading ? (
    <FaSpinner className="spin" size={13} />
  ) : (
    <FaSearch size={14} />
  )}
</button>

        </div>


        {/* SUGGESTIONS */}

        {suggestions.length > 0 && (

          <div
            style={{
              position: "absolute",

              top: "56px",

              left: 0,

              right: 0,

              background: "#FFFFFF",

              borderRadius: "18px",

              border:
                "1px solid #E5E7EB",

              boxShadow:
                "0 18px 45px rgba(15,23,42,0.14)",

              zIndex: 10000,

              overflow: "hidden",
            }}
          >

            {suggestions.map(
              (product) => (

                <div
                  key={product._id}

                  onClick={() => {

                    setSearch(
                      product.name
                    );

                    setSuggestions([]);

                    navigate(
                      `/product/${product._id}`
                    );

                  }}

                  style={{
                    display: "flex",

                    alignItems:
                      "center",

                    gap: "12px",

                    padding:
                      "11px 13px",

                    cursor:
                      "pointer",

                    borderBottom:
                      "1px solid #F1F5F9",
                  }}
                >

                  <img
                    src={product.image}
                    alt=""

                    style={{
                      width: "42px",

                      height: "42px",

                      borderRadius: "10px",

                      objectFit: "cover",

                      flexShrink: 0,
                    }}
                  />

                  <div
                    style={{
                      minWidth: 0,
                    }}
                  >

                    <div
                      style={{
                        fontSize: "13px",

                        fontWeight: "700",

                        color: "#111827",

                        overflow:
                          "hidden",

                        textOverflow:
                          "ellipsis",

                        whiteSpace:
                          "nowrap",
                      }}
                    >
                      {product.name}
                    </div>

                    <div
                      style={{
                        fontSize: "11px",

                        color: "#6B7280",

                        marginTop: "3px",
                      }}
                    >
                      {Number(
                        product.price
                      ).toLocaleString()} FCFA
                    </div>

                  </div>

                </div>

              )
            )}

          </div>

        )}

      </div>

    )}


    {/* ===================================================
        ICONES
    =================================================== */}

    <div
      style={{
        display: "flex",

        alignItems: "center",

        gap: compactHeader
          ? (
              window.innerWidth < 768
                ? "6px"
                : "9px"
            )
          : (
              window.innerWidth < 768
                ? "5px"
                : "8px"
            ),

        flexShrink: 0,
      }}
    >

      {/* FAVORIS */}

      <Link
        to="/favorites"

        style={{
          textDecoration: "none",

          color: "#111827",
        }}
      >

        <div
          style={{
            width:
              window.innerWidth < 768
                ? "36px"
                : "42px",

            height:
              window.innerWidth < 768
                ? "36px"
                : "42px",

            borderRadius:
              window.innerWidth < 768
                ? "11px"
                : "13px",

            background: "#FFFFFF",

            display: "flex",

            justifyContent:
              "center",

            alignItems:
              "center",

            position: "relative",

            border:
              "1px solid #F1F5F9",

            boxShadow:
              "0 3px 10px rgba(15,23,42,0.05)",
          }}
        >

          <FaHeart
            style={{
              fontSize:
                window.innerWidth < 768
                  ? "16px"
                  : "18px",
            }}
          />

          {favoritesCount > 0 && (

            <span
              style={{
                position: "absolute",

                top: "-5px",

                right: "-4px",

                minWidth: "16px",

                height: "16px",

                padding: "0 3px",

                borderRadius: "999px",

                background:
                  "#5B3CC4",

                color: "#FFFFFF",

                display: "flex",

                justifyContent:
                  "center",

                alignItems:
                  "center",

                fontSize: "9px",

                fontWeight: "800",

                border:
                  "2px solid white",
              }}
            >
              {favoritesCount}
            </span>

          )}

        </div>

      </Link>


      {/* PANIER */}

      <Link
        to="/checkout"

        state={{
          cart
        }}

        style={{
          textDecoration:
            "none",

          color:
            "#111827",
        }}
      >

        <div
          style={{
            width:
              window.innerWidth < 768
                ? "36px"
                : "42px",

            height:
              window.innerWidth < 768
                ? "36px"
                : "42px",

            borderRadius:
              window.innerWidth < 768
                ? "11px"
                : "13px",

            background:
              "#FFFFFF",

            display: "flex",

            justifyContent:
              "center",

            alignItems:
              "center",

            position:
              "relative",

            border:
              "1px solid #F1F5F9",

            boxShadow:
              "0 3px 10px rgba(15,23,42,0.05)",
          }}
        >

          <FaShoppingCart
            style={{
              fontSize:
                window.innerWidth < 768
                  ? "16px"
                  : "18px",
            }}
          />

          <span
            style={{
              position:
                "absolute",

              top: "-5px",

              right: "-4px",

              minWidth: "16px",

              height: "16px",

              padding:
                "0 3px",

              borderRadius:
                "999px",

              background:
                "#5B3CC4",

              color:
                "#FFFFFF",

              display: "flex",

              justifyContent:
                "center",

              alignItems:
                "center",

              fontSize: "9px",

              fontWeight: "800",

              border:
                "2px solid white",
            }}
          >
            {cart.reduce(
              (total, item) =>
                total +
                (item.quantity || 1),
              0
            )}
          </span>

        </div>

      </Link>


      {/* COMPTE */}

      <Link
        to="/account"

        style={{
          textDecoration:
            "none",

          color:
            "#111827",
        }}
      >

        <div
          style={{
            width:
              window.innerWidth < 768
                ? "36px"
                : "42px",

            height:
              window.innerWidth < 768
                ? "36px"
                : "42px",

            borderRadius:
              window.innerWidth < 768
                ? "11px"
                : "13px",

            background:
              "#FFFFFF",

            display: "flex",

            justifyContent:
              "center",

            alignItems:
              "center",

            border:
              "1px solid #F1F5F9",

            boxShadow:
              "0 3px 10px rgba(15,23,42,0.05)",
          }}
        >

          <FaUserCircle
            style={{
              fontSize:
                window.innerWidth < 768
                  ? "18px"
                  : "20px",
            }}
          />

        </div>

      </Link>

    </div>

  </div>


  {/* =====================================================
      RECHERCHE MOBILE
  ===================================================== */}

  {window.innerWidth < 768 && !compactHeader && (

    <div
      style={{
        position:
          "relative",

        width: "100%",

        marginTop: "8px",
      }}
    >

      <div
        style={{
          width: "100%",

          height: "43px",

          background:
            "#F8FAFC",

          border:
            "1px solid #E5E7EB",

          borderRadius:
            "999px",

          display: "flex",

          alignItems:
            "center",

          overflow: "hidden",

          boxShadow:
            "0 2px 8px rgba(15,23,42,0.04)",
        }}
      >

        <FaSearch
          style={{
            marginLeft: "14px",

            color: "#94A3B8",

            fontSize: "14px",

            flexShrink: 0,
          }}
        />

        <input
          type="text"

          placeholder={
            placeholders[placeholderIndex]
          }

          value={search}

          onChange={(e) => {

            const value =
              e.target.value;

            setSearch(value);

            if (
              value.trim()
            ) {

              const filtered =
                products.filter(
                  (product) =>
                    product.name
                      .toLowerCase()
                      .includes(
                        value.toLowerCase()
                      )
                );

              setSuggestions(
                filtered.slice(0, 5)
              );

            } else {

              setSuggestions([]);

            }

          }}

          onKeyDown={(e) => {

  if (
    e.key === "Enter" &&
    search.trim()
  ) {

    setSuggestions([]);

    searchProducts();

  }

}}

          style={{
            flex: 1,

            minWidth: 0,

            border: "none",

            outline: "none",

            padding:
              "8px 10px",

            fontSize: "13px",

            background:
              "transparent",

            color: "#111827",

            WebkitTextFillColor:
              "#111827",

            caretColor:
              "#4B2E83",
          }}
        />

        <button
  type="button"

  onClick={(e) => {

    e.preventDefault();
    e.stopPropagation();

    if (!search.trim()) {
      return;
    }

    setSuggestions([]);

    searchProducts();

  }}

  style={{
    width: "42px",

    height: "42px",

    border: "none",

    background: "#4B2E83",

    color: "#FFFFFF",

    display: "flex",

    alignItems: "center",

    justifyContent: "center",

    flexShrink: 0,

    cursor: "pointer",

    touchAction: "manipulation",

    WebkitTapHighlightColor: "transparent",

    borderRadius: "0 999px 999px 0",
  }}
>
  {loading ? (
    <FaSpinner
      className="spin"
      size={13}
    />
  ) : (
    <FaSearch
      size={14}
    />
  )}
</button>

      </div>


      {/* SUGGESTIONS MOBILE */}

      {suggestions.length > 0 && (

        <div
          style={{
            position:
              "absolute",

            top: "48px",

            left: 0,

            right: 0,

            background:
              "#FFFFFF",

            borderRadius:
              "16px",

            border:
              "1px solid #E5E7EB",

            boxShadow:
              "0 18px 40px rgba(15,23,42,0.16)",

            zIndex:
              10000,

            overflow:
              "hidden",

            maxHeight:
              "300px",

            overflowY:
              "auto",
          }}
        >

          {suggestions.map(
            (product) => (

              <div
                key={product._id}

                onClick={() => {

                  setSearch(
                    product.name
                  );

                  setSuggestions([]);

                  navigate(
                    `/product/${product._id}`
                  );

                }}

                style={{
                  display: "flex",

                  alignItems:
                    "center",

                  gap: "10px",

                  padding:
                    "11px",

                  cursor:
                    "pointer",

                  borderBottom:
                    "1px solid #F1F5F9",
                }}
              >

                <img
                  src={product.image}

                  alt=""

                  style={{
                    width: "42px",

                    height: "42px",

                    borderRadius:
                      "10px",

                    objectFit:
                      "cover",

                    flexShrink: 0,
                  }}
                />

                <div
                  style={{
                    minWidth: 0,
                  }}
                >

                  <div
                    style={{
                      fontSize:
                        "13px",

                      fontWeight:
                        "700",

                      color:
                        "#111827",

                      overflow:
                        "hidden",

                      textOverflow:
                        "ellipsis",

                      whiteSpace:
                        "nowrap",
                    }}
                  >
                    {product.name}
                  </div>

                  <div
                    style={{
                      fontSize:
                        "11px",

                      color:
                        "#64748B",

                      marginTop:
                        "3px",
                    }}
                  >
                    {Number(
                      product.price
                    ).toLocaleString()} FCFA
                  </div>

                </div>

              </div>

            )
          )}

        </div>

      )}

    </div>

  )}


  {/* =====================================================
      TABS / NAVIGATION
  ===================================================== */}

  <div
    style={{
      display: "flex",

      gap:
        window.innerWidth < 768
          ? "8px"
          : "10px",

      marginTop:
        window.innerWidth < 768
          ? "8px"
          : "12px",

      overflowX: "auto",

      overflowY: "hidden",

      paddingBottom: "2px",

      scrollbarWidth:
        "none",

      msOverflowStyle:
        "none",

      WebkitOverflowScrolling:
        "touch",

      width: "100%",

      opacity: compactHeader ? 0 : 1,

      transform:
        compactHeader
          ? "translateY(-8px)"
          : "translateY(0)",

      pointerEvents:
        compactHeader
          ? "none"
          : "auto",

      transition:
        "opacity .25s ease, transform .35s cubic-bezier(.22,1,.36,1)",
    }}
  >

    {[
      {
        name: "AI Mode",
        link: "/ai-mode",
      },

      {
        name: "Produits",
        link: "/boutique",
      },

      {
        name: "Boutique",
        link: "/boutique",
      },

      ...(admin
        ? [

            {
              name: "Admin",
              link:
                "/admin-login",
            },

            {
              name: "Livreur",
              link:
                "/driver-login",
            },

            {
              name: "Livreurs",
              link:
                "/drivers",
            },

          ]
        : []),

    ].map(
      (item, index) => (

        <Link
          key={index}

          to={item.link}

          style={{
            textDecoration:
              "none",

            flexShrink: 0,
          }}
        >

          <button
            type="button"

            style={{
              border: "none",

              background:
                index === 1
                  ? "#4B2E83"
                  : "#F3F4F6",

              color:
                index === 1
                  ? "#FFFFFF"
                  : "#111827",

              padding:
                window.innerWidth < 768
                  ? "8px 14px"
                  : "9px 16px",

              borderRadius:
                "999px",

              fontWeight:
                "800",

              fontSize:
                window.innerWidth < 768
                  ? "11px"
                  : "12px",

              cursor:
                "pointer",

              whiteSpace:
                "nowrap",

              boxShadow:
                index === 1
                  ? "0 5px 14px rgba(75,46,131,0.20)"
                  : "none",
            }}
          >
            {item.name}
          </button>

        </Link>

      )
    )}

  </div>

</div>


{/* =========================================================
    ESPACE SOUS LE HEADER FIXE
========================================================= */}

<div
  style={{
    height: compactHeader
      ? (
          window.innerWidth < 768
            ? "68px"
            : "82px"
        )
      : (
          window.innerWidth < 768
            ? "148px"
            : "105px"
        ),

    transition:
      "height .42s cubic-bezier(.22,1,.36,1)",
  }}
/>


{/* =========================================================
    BIG SEARCH
========================================================= */}

<div
  style={{
    background: "#FFFFFF",
    borderRadius: "18px",
    padding: "8px",
    display: "flex",
    alignItems: "center",
    gap: image ? "5px" : "8px",
    marginTop: "14px",
    marginBottom: "18px",
    border: "1px solid #F1F5F9",
    boxShadow: "0 4px 15px rgba(0,0,0,0.04)",
    overflow: "hidden",
  }}
>

  {/* CAMERA */}

  <button
    onClick={() =>
      document
        .getElementById("imageUpload")
        .click()
    }
    style={{
      width: "38px",
      height: "38px",
      border: "none",
      borderRadius: "10px",
      background: "#F5F3FF",
      color: "#4B2E83",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      cursor: "pointer",
      flexShrink: 0,
    }}
  >
    <FaCamera size={15} />
  </button>

  {/* INPUT */}

  <div
    style={{
      flex: 1,
      minWidth: image ? "80px" : "140px",
      display: "flex",
      alignItems: "center",
      gap: "6px",
      background: "#F9FAFB",
      borderRadius: "12px",
      padding: image ? "0 6px" : "0 10px",
      height: "38px",
      overflow: "hidden",
    }}
  >

    <FaSearch
      style={{
        color: "#9CA3AF",
        fontSize: "12px",
        flexShrink: 0,
      }}
    />

    <input
      type="text"
      placeholder={placeholders[placeholderIndex]}
      value={search}
      onChange={(e) =>
        setSearch(e.target.value)
      }
      style={{
        flex: 1,
        minWidth: 0,
        border: "none",
        outline: "none",
        background: "transparent",
        fontSize: "12px",
        color: "#111827",
        WebkitTextFillColor: "#111827",
        caretColor: "#4B2E83",
      }}
    />

  </div>

  {/* MICRO */}

  <button
    onClick={startVoice}
    style={{
      width: "38px",
      height: "38px",
      border: "none",
      borderRadius: "10px",
      background: "#F5F3FF",
      color: "#4B2E83",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      cursor: "pointer",
      flexShrink: 0,
    }}
  >
    <FaMicrophone size={15} />
  </button>

  {/* IMAGE */}

  {image && (

    <div
      style={{
        position: "relative",
        width: "45px",
        height: "45px",
        flexShrink: 0,
      }}
    >

      <img
        src={URL.createObjectURL(image)}
         alt=""
        style={{
          width: "45px",
          height: "45px",
          borderRadius: "10px",
          objectFit: "cover",
          boxShadow:
            "0 3px 10px rgba(0,0,0,.08)",
        }}
      />

      <button
        onClick={() =>
          setImage(null)
        }
        style={{
          position: "absolute",
          top: "-4px",
          right: "-4px",
          width: "16px",
          height: "16px",
          borderRadius: "50%",
          border: "none",
          background: "#EF4444",
          color: "#FFFFFF",
          cursor: "pointer",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          fontSize: "8px",
          fontWeight: "700",
        }}
      >
        ✕
      </button>

    </div>

  )}

  {/* RECHERCHE */}

  <button
    onClick={searchProducts}
    disabled={loading}
    style={{
      border: "none",
      background:
        "linear-gradient(135deg,#4B2E83,#6D28D9)",
      color: "#FFFFFF",
      height: "38px",
      minWidth: image ? "38px" : "95px",
      padding: image ? "0 10px" : "0 12px",
      borderRadius: "12px",
      fontWeight: "700",
      fontSize: "11px",
      cursor: "pointer",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      gap: "5px",
      boxShadow:
        "0 4px 12px rgba(75,46,131,.18)",
      flexShrink: 0,
      whiteSpace: "nowrap",
    }}
  >

    {loading ? (
      <>
        <FaSpinner
          className="spin"
          size={11}
        />
        {!image && "Recherche..."}
      </>
    ) : (
      <>
        <FaSearch size={11} />
        {!image && "Rechercher"}
      </>
    )}

  </button>

</div>

   {/* QUICK ACTIONS */}

<div
  style={{
    display: "grid",

    gridTemplateColumns:
      window.innerWidth < 768
        ? "repeat(2,1fr)"
        : "repeat(4,1fr)",

    gap: "12px",

    marginBottom: "22px",
  }}
>


  {/* CATEGORIES */}

  <Link
    to="/boutique"

    style={{
      textDecoration: "none",
    }}
  >

    <div
      style={quickCard}
    >

      <div
        style={{
          fontSize: "26px",
          marginBottom: "10px",
        }}
      >
        <FaBoxOpen />
      </div>

      <h3 style={quickTitle}>
        Explorer catégories
      </h3>

    </div>

  </Link>

  {/* DEVIS */}

  <a
    href="https://wa.me/237694641329"

    target="_blank"

    style={{
      textDecoration: "none",
    }}
  >

    <div
      style={quickCard}
    >

      <div
        style={{
          fontSize: "26px",
          marginBottom: "10px",
        }}
      >
        <FaWhatsapp />
      </div>

      <h3 style={quickTitle}>
        Whatsapp
      </h3>

    </div>

  </a>

  {/* PRODUITS */}

  <Link
    to="/boutique"

    style={{
      textDecoration: "none",
    }}
  >

    <div
      style={quickCard}
    >

      <div
        style={{
          fontSize: "26px",
          marginBottom: "10px",
        }}
      >
       <FaFire />
      </div>

      <h3 style={quickTitle}>
        Produits populaires
      </h3>

    </div>

  </Link>

  {/* OFFRES */}

  <Link
    to="/boutique"

    style={{
      textDecoration: "none",
    }}
  >

    <div
      style={quickCard}
    >

      <div
        style={{
          fontSize: "26px",
          marginBottom: "10px",
        }}
      >
<FaCrown />
      </div>

      <h3 style={quickTitle}>
        Offres exclusives
      </h3>

    </div>

  </Link>

</div>

       {/* CATEGORIES */}

<div
  style={{
    marginBottom: "35px",
  }}
>

  <div
    style={{
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: "16px",
    }}
  >

    <h2
      style={{
        margin: 0,
        fontSize: "22px",
        fontWeight: "800",
        color: "#1f2937",
      }}
    >
      Catégories
    </h2>

    <Link
    translate="no"
      to="/boutique"
      style={{
        textDecoration: "none",
      }}
    >

      <button
       style={{
          border: "none",

          background: "#4B2E83",

          color: "white",

          padding: "8px 14px",

          borderRadius: "12px",

          fontWeight: "700",

          fontSize: "12px",

          cursor: "pointer",

          boxShadow:
            "0 4px 12px rgba(75,46,131,0.15)",

          transition: "0.3s",
        }}
      >
        Voir tout
      </button>

    </Link>

  </div>

  <div
    style={{
      display: "flex",
      gap: "8px",
      overflowX: "auto",
      paddingBottom: "8px",
      scrollbarWidth: "none",
      msOverflowStyle: "none",
    }}
  >

    {[
      "Tous",

      ...new Set(
        products.map(
          (product) =>
            product.category
        )
      ),

    ].map((category, index) => (

      <button
        key={index}

        onClick={() =>
          setSelectedCategory(
            category
          )
        }

        style={{
          border: "none",

          background:
            selectedCategory === category
              ? "#4B2E83"
              : "#FFFFFF",

          color:
            selectedCategory === category
              ? "#FFFFFF"
              : "#374151",

          padding: "10px 18px",

          borderRadius: "14px",

          fontWeight: "700",

          cursor: "pointer",

          fontSize: "12px",

          whiteSpace: "nowrap",

          boxShadow:
            selectedCategory === category
              ? "0 6px 15px rgba(75,46,131,0.18)"
              : "0 3px 10px rgba(0,0,0,0.04)",

          transition: "all 0.25s ease",
        }}
      >
        {category}
      </button>

    ))}

  </div>

</div>

{/* PRODUITS */}

<div
  style={{
    marginBottom: "35px",
  }}
>

  <div
    style={{
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: "20px",
    }}
  >

    <h2
      style={{
        display: "flex",
        alignItems: "center",
        gap: "8px",

        margin: 0,

        fontSize: "22px",

        fontWeight: "800",

        color: "#1f2937",
      }}
    >
      Meilleures offres

      <FaFireAlt
        style={{
          color: "#ff6b00",

          fontSize: "22px",

          filter:
            "drop-shadow(0 3px 8px rgba(255,107,0,0.25))",
        }}
      />
    </h2>

    <Link
    translate="no"
      to="/boutique"
      style={{
        textDecoration: "none",
      }}
    >

      <button
        style={{
          border: "none",

          background: "#4B2E83",

          color: "white",

          padding: "8px 14px",

          borderRadius: "12px",

          fontWeight: "700",

          fontSize: "12px",

          cursor: "pointer",

          boxShadow:
            "0 4px 12px rgba(75,46,131,0.15)",

          transition: "0.3s",
        }}
      >
        Voir tout
      </button>

    </Link>

  </div>

  {/* GRID */}

<div
  style={{
    display: "grid",

    gridTemplateColumns:
      window.innerWidth < 768
        ? "repeat(2,1fr)"
        : "repeat(auto-fill,minmax(240px,1fr))",

    gap: "14px",

    width: "100%",
  }}
>

{aiProducts.length > 0 && (

<div
style={{
marginBottom:"20px",
gridColumn:"1/-1",
}}
>

<h2
style={{
display:"flex",
alignItems:"center",
gap:"8px",

fontSize:"20px",

fontWeight:"800",

color:"#111827",

marginBottom:"10px",
}}
>

<FaRobot
style={{
color:"#4B2E83",
}}
/>

Résultats IA

</h2>

</div>

)}

{aiProducts.length === 0
&& image && (

<div
style={{

background:"#FFFFFF",

padding:"25px",

borderRadius:"20px",

textAlign:"center",

marginBottom:"20px",

gridColumn:"1/-1",

boxShadow:
"0 4px 15px rgba(0,0,0,0.05)",

border:
"1px solid #F3F4F6",

}}

>

<div
style={{

width:"80px",

height:"80px",

margin:"0 auto 18px auto",

borderRadius:"50%",

background:
"linear-gradient(135deg,#EEF2FF,#E0E7FF)",

display:"flex",

justifyContent:"center",

alignItems:"center",

boxShadow:
"0 4px 12px rgba(79,70,229,0.12)",

}}

>

<FaRobot
style={{
fontSize:"36px",
color:"#4F46E5",
}}
/>

</div>

<h2
style={{

color:"#111827",

fontSize:"22px",

fontWeight:"800",

marginBottom:"8px",

}}
>

Aucun produit similaire trouvé

</h2>

<p
style={{

color:"#6B7280",

lineHeight:"24px",

fontSize:"14px",

maxWidth:"400px",

margin:"0 auto",

}}
>

Essayez une autre image ou utilisez une photo plus claire pour améliorer la recherche IA.

</p>

</div>

)}

{searchClicked &&
(aiProducts.length > 0
  ? aiProducts
  : randomizedProducts)
.filter((product) => {

  const normalize = (text = "") =>
    text
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^\w\s]/g, " ");

  const stopWords = [
    "je","j","veux","voudrais","cherche",
    "recherche","montre","moi","une","un",
    "des","de","du","la","le","les","pour",
    "avec","et","ou","svp","stp","sil","plait"
  ];

  const keywords = normalize(searchQuery)
    .split(/\s+/)
    .filter(
      word =>
        word &&
        !stopWords.includes(word)
    );

  const text = normalize(`
    ${product.name}
    ${product.category}
    ${product.description || ""}
    ${product.brand || ""}
  `);

  const matchSearch =
    keywords.length === 0
      ? true
      : keywords.some(word => text.includes(word));

  const matchCategory =
    selectedCategory === "Tous"
      ? true
      : product.category === selectedCategory;

  return matchSearch && matchCategory;

}).length === 0 && (

<div
  style={{
    gridColumn: "1 / -1",
    background: "#FFFFFF",
    border: "1px solid #ECEFF3",
    borderRadius: "18px",
    padding: "18px 16px",
    marginBottom: "18px",
    textAlign: "center",
    boxShadow: "0 4px 14px rgba(0,0,0,.05)",
  }}
>

  <div
    style={{
      width: "54px",
      height: "54px",
      margin: "0 auto 12px",
      borderRadius: "50%",
      background: "#F3F4FF",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
    }}
  >

    <FaSearch
      style={{
        fontSize: "22px",
        color: "#4B2E83",
      }}
    />

  </div>

  <h3
    style={{
      margin: 0,
      fontSize: "18px",
      fontWeight: "800",
      color: "#111827",
    }}
  >
    Aucun résultat trouvé
  </h3>

  <p
    style={{
      marginTop: "8px",
      color: "#6B7280",
      fontSize: "13px",
      lineHeight: "21px",
    }}
  >
    Aucun produit ne correspond à

    <br />

    <span
      style={{
        color: "#4B2E83",
        fontWeight: "700",
      }}
    >
      "{searchQuery}"
    </span>

    <br /><br />

    Découvrez nos recommandations ci-dessous.
  </p>

</div>

)}

{(
  (
    searchClicked &&
    (aiProducts.length > 0
      ? aiProducts
      : randomizedProducts)
      .filter((product) => {

        const normalize = (text = "") =>
          text
            .toLowerCase()
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .replace(/[^\w\s]/g, " ");

        const stopWords = [
          "je","j","veux","voudrais","cherche",
          "recherche","montre","moi","une","un",
          "des","de","du","la","le","les","pour",
          "avec","et","ou","svp","stp","sil","plait"
        ];

        const keywords = normalize(searchQuery)
          .split(/\s+/)
          .filter(
            word =>
              word &&
              !stopWords.includes(word)
          );

        const text = normalize(`
          ${product.name}
          ${product.category}
          ${product.description || ""}
          ${product.brand || ""}
        `);

        const matchSearch =
          keywords.length === 0
            ? true
            : keywords.some(word =>
                text.includes(word)
              );

        const matchCategory =
          selectedCategory === "Tous"
            ? true
            : product.category === selectedCategory;

        return matchSearch && matchCategory;

      }).length > 0
  )
    ? (aiProducts.length > 0
        ? aiProducts
        : randomizedProducts).filter((product) => {

        const normalize = (text = "") =>
          text
            .toLowerCase()
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .replace(/[^\w\s]/g, " ");

        const stopWords = [
          "je","j","veux","voudrais","cherche",
          "recherche","montre","moi","une","un",
          "des","de","du","la","le","les","pour",
          "avec","et","ou","svp","stp","sil","plait"
        ];

        const keywords = normalize(searchQuery)
          .split(/\s+/)
          .filter(
            word =>
              word &&
              !stopWords.includes(word)
          );

        const text = normalize(`
          ${product.name}
          ${product.category}
          ${product.description || ""}
          ${product.brand || ""}
        `);

        const matchSearch =
          !searchClicked ||
          keywords.length === 0
            ? true
            : keywords.some(word =>
                text.includes(word)
              );

        const matchCategory =
          selectedCategory === "Tous"
            ? true
            : product.category === selectedCategory;

        return matchSearch && matchCategory;

      })
    : randomizedProducts.filter(product =>
  selectedCategory === "Tous"
    ? true
    : product.category === selectedCategory
)
)

.slice(0, visibleProducts)

.map((product) => (

<Link
  to={`/product/${product._id}`}
  key={product._id}
  onClick={() => playSound()}
  state={{
  scrollY: window.scrollY,

  productsOrder:
    randomizedProducts.map(
      (p) => p._id
    ),

  visibleProducts:
    visibleProducts,
}}
style={{
textDecoration:"none",
color:"#111827",
}}
>

<div

onMouseEnter={(e) => {

  e.currentTarget.style.transform =
    "translateY(-8px)";

  e.currentTarget.style.boxShadow =
    "0 18px 35px rgba(0,0,0,.10)";

  e.currentTarget.querySelector("img").style.transform =
    "scale(1.06)";

}}

onMouseLeave={(e) => {

  e.currentTarget.style.transform =
    "translateY(0)";

  e.currentTarget.style.boxShadow =
    "0 4px 12px rgba(0,0,0,.05)";

  e.currentTarget.querySelector("img").style.transform =
    "scale(1)";

}}

style={{

background:"#FFFFFF",

borderRadius:"16px",

overflow:"hidden",

border:"1px solid #F3F4F6",

boxShadow:"0 4px 12px rgba(0,0,0,0.05)",

cursor:"pointer",

transition:"all .35s ease",

position:"relative",

}}
>

{/* IMAGE */}

<div
style={{

width:"100%",

height:
window.innerWidth < 768
? "190px"
: "230px",

background:"#F9FAFB",

overflow:"hidden",

display:"flex",

alignItems:"center",

justifyContent:"center",

}}
>

<img
src={product.image}
alt={product.name}

loading="lazy"
decoding="async"

style={{

width:"100%",

height:"100%",

objectFit:"cover",

display:"block",

transition:"transform .35s ease",

}}

 />

</div>

{/* FAVORIS */}

<button

  onClick={async (e) => {

    e.preventDefault();

    const user =
      JSON.parse(
        localStorage.getItem("user")
      );

    // ======================
    // FAVORIS LOCAL
    // ======================

    const clientId =

      user?._id ||

      localStorage.getItem(
        "guestId"
      ) ||

      (() => {

        const newGuestId =

          "guest_" +
          Date.now();

        localStorage.setItem(
          "guestId",
          newGuestId
        );

        return newGuestId;

      })();

    const favoritesKey =
      `favorites_${clientId}`;

    let favorites =

      JSON.parse(
        localStorage.getItem(
          favoritesKey
        )
      ) || [];

    const alreadyExists =
      favorites.find(
        (item) =>
          item._id === product._id
      );

    // ======================
    // RETIRER FAVORI
    // ======================

    if (alreadyExists) {

  favorites =

    favorites.filter(
      (item) =>
        item._id !== product._id
    );

  // ======================
  // DELETE FAVORITE SERVER
  // ======================

  if (user?._id) {

    try {

      await axios.delete(

        `https://konanshopping.com/api/favorites/${user._id}/${product._id}`,

        { headers: authHeaders }

      );

    }

    catch(err){

      console.log(err);

    }

  }

}

    // ======================
    // AJOUTER FAVORI
    // ======================

    else {

      favorites.push(product);

      // CLIENT CONNECTÉ

      if (user?._id) {

        try {

          await axios.post(
            "https://konanshopping.com/api/favorites",
            {

              userId: user._id,

              productId:
                product._id,

            },
            { headers: authHeaders }
          );

        }

        catch(err){

          console.log(err);

        }

      }

    }

    // ======================
    // SAVE LOCALSTORAGE
    // ======================

    localStorage.setItem(

      favoritesKey,

      JSON.stringify(favorites)

    );

    // ======================
    // FAVORITES COUNT
    // ======================

    localStorage.setItem(

      "favoritesCount",

      favorites.length

    );

    // ======================
    // UPDATE UI
    // ======================

    window.dispatchEvent(
      new Event("favoritesUpdated")
    );

window.dispatchEvent(
  new StorageEvent("storage")
);

  }}

  style={{

    position: "absolute",

    top: "12px",

    right: "12px",

    width: "34px",

    height: "34px",

    borderRadius: "50%",

    border: "none",

    background:

JSON.parse(
  localStorage.getItem(
    favoritesKey
  )
)?.find(
  (item) =>
    item._id === product._id
)

? "#2563eb"

: "#f3f4f6",

    color:

JSON.parse(
  localStorage.getItem(
    favoritesKey
  )
)?.find(
  (item) =>
    item._id === product._id
)

? "white"

: "#9ca3af",

    fontSize: "15px",

    cursor: "pointer",

    display: "flex",

    alignItems: "center",

    justifyContent: "center",

    transition: "all 0.3s ease",

    boxShadow:
      "0 6px 18px rgba(0,0,0,0.10)",

    zIndex: "10",

  }}

  onMouseEnter={(e) => {

    e.currentTarget.style.transform =
      "scale(1.08)";

    e.currentTarget.style.boxShadow =
      "0 10px 22px rgba(37,99,235,0.18)";

  }}

  onMouseLeave={(e) => {

    e.currentTarget.style.transform =
      "scale(1)";

    e.currentTarget.style.boxShadow =
      "0 6px 18px rgba(0,0,0,0.10)";

  }}

>

  <FaHeart

style={{

color:

JSON.parse(
localStorage.getItem(
favoritesKey
)
)?.find(
(item) =>
item._id === product._id
)

? "white"

: "#9ca3af",

transition: "0.3s",

filter:

JSON.parse(
localStorage.getItem(
favoritesKey
)
)?.find(
(item) =>
item._id === product._id
)

? "drop-shadow(0 2px 8px rgba(255,255,255,0.35))"

: "none",

}}

/>

</button>


  {/* CONTENT */}

  <div
    style={{
      padding: "14px", // réduit
    }}
  >

    <p
      style={{
        color: "#6b7280",
        fontSize: "12px", // réduit
        marginBottom: "6px",
      }}
    >
      {product.category}
    </p>

    <h3
      style={{
        margin: 0,

        fontSize:
          window.innerWidth < 768
            ? "15px"
            : "18px", // réduit

        color: "#111827",

        marginBottom: "8px",

        lineHeight: "1.3",
      }}
    >
      {product.name}
    </h3>

   <div
  style={{
    display: "flex",

    alignItems: "center",

    gap: "5px",

    marginBottom: "8px",

    flexWrap: "wrap",
  }}
>

<div
  style={{
    display: "flex",

    alignItems: "center",

    gap: "2px",
  }}
>

{[...Array(5)].map(
(_, index) => {

const averageRating =

product.reviews?.length > 0

? (

product.reviews.reduce(

(total, review)=>

total + review.rating,

0

) /

product.reviews.length

)

: 0;

return (

<FaStar
  key={index}

  style={{
    fontSize: "10px",

    color:
      index <
      Math.round(
        averageRating
      )

        ? "#f59e0b"

        : "#d1d5db",
  }}
/>

);

}
)}

</div>

<span
  style={{
    color: "#111827",

    fontSize: "11px",

    fontWeight: "800",
  }}
>

{

product.reviews?.length > 0

? (

product.reviews.reduce(

(total, review)=>

total + review.rating,

0

) /

product.reviews.length

).toFixed(1)

: "0.0"

}

</span>

<span
  style={{
    color: "#6b7280",

    fontSize: "11px",

    fontWeight: "500",
  }}
>

(

{product.reviews?.length || 0}

avis )

</span>

</div>

    <h2
      style={{
        margin: 0,

        color: "#4B2E83",

        fontSize:
          window.innerWidth < 768
            ? "18px"
            : "24px", // réduit

        marginBottom: "14px",

        fontWeight: "900",
      }}
    >
      {product.price} FCFA
    </h2>

    <div
      style={{
        display: "flex",
        gap: "8px", // réduit
      }}
    >
    

  <button
onClick={(e) => {

  e.preventDefault();
  e.stopPropagation();

  addToCart(product);

  setAddedProduct(product._id);

  setTimeout(() => {
    setAddedProduct(null);
  }, 1500);

}}
translate="no"
style={{
  flex:1,
  border:"1px solid #e5e7eb",

  background:
  addedProduct === product._id
  ? "#10b981"
  : "white",

  color:
  addedProduct === product._id
  ? "#ffffff"
  : "#111827",

  padding:"10px",

  borderRadius:"12px",

  fontWeight:"700",

  fontSize:"12px",

  cursor:"pointer",

  transition:"all .25s ease",

  transform:
  addedProduct === product._id
  ? "scale(1.03)"
  : "scale(1)",

  boxShadow:
  addedProduct === product._id
  ? "0 6px 15px rgba(16,185,129,.25)"
  : "none",
}}
>
{
addedProduct === product._id
? "✓ Ajouté"
: "Ajouter"
}
</button>

      <button
      translate="no"
        style={{
          flex: 1,

          border: "none",

          background:
            "linear-gradient(135deg,#6d28d9,#4f46e5)",

          color: "white",

          padding: "10px", // réduit

          borderRadius: "12px", // réduit

          fontWeight: "700",

          fontSize: "12px", // réduit

          cursor: "pointer",
        }}
      >
        Buy Now
      </button>

    </div>

</div>

</div>

</Link>
))
}

{/* BOTTOM NAVIGATION */}

<div
  style={{
  position: "fixed",

  bottom: showBottomNav ? "8px" : "-120px",

  left: "50%",

  transform: "translateX(-50%)",

  width: "92%",

  maxWidth: "500px",

  background: "rgba(255,255,255,0.95)",

  backdropFilter: "blur(14px)",

  border: "1px solid rgba(255,255,255,0.4)",

  borderRadius: "18px",

  display: "flex",

  justifyContent: "space-around",

  alignItems: "center",

  padding: "4px 0",

  zIndex: 999,

  boxShadow: "0 6px 20px rgba(0,0,0,0.05)",

  transition: "all .35s ease",

  opacity: showBottomNav ? 1 : 0,

  pointerEvents: showBottomNav ? "auto" : "none",
}}
>

  {[
    {
      icon: <FaHome />,
      name: "Accueil",
      link: "/",
    },

    {
      icon: <FaThLarge />,
      name: "Catégories",
      link: "/boutique",
    },

    {
      icon: <FaUser />,
      name: "Compte",
      link: "/account",
    },

    {
      icon: <FaShoppingCart />,
      name: "Panier",
      link: "/checkout",
    },

    {
      icon: <FaComments />,
      name: "Messages",
      link: "https://wa.me/237694641329",
    },

  ].map((item, index) => (

    item.name === "Messages" ? (

      <a
        key={index}
        href={item.link}
        target="_blank"
        rel="noreferrer"
        style={{
          textDecoration: "none",
        }}
      >

        <div
          className="bottomNavItem"

          onTouchStart={(e)=>{
            e.currentTarget.style.transform="scale(0.95)";
          }}

          onTouchEnd={(e)=>{
            e.currentTarget.style.transform="scale(1)";
          }}

          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: "1px",
            cursor: "pointer",
            padding: "3px 8px",
            borderRadius: "12px",
            transition: "0.2s ease",
          }}
        >

          <div
            className="bottomNavIcon"
            style={{
              fontSize: "20px",
            }}
          >
            {item.icon}
          </div>

          <span
            style={{
              fontSize: "9px",
              color:
                index === 0
                  ? "#4B2E83"
                  : "#6b7280",
              fontWeight:
                index === 0
                  ? "700"
                  : "500",
            }}
          >
            {item.name}
          </span>

        </div>

      </a>

    ) : (

      <Link
        key={index}
        to={item.link}
        state={
          item.name === "Panier"
            ? { cart }
            : undefined
        }
        style={{
          textDecoration: "none",
        }}
      >

        <div
          className="bottomNavItem"

          onTouchStart={(e)=>{
            e.currentTarget.style.transform="scale(0.95)";
          }}

          onTouchEnd={(e)=>{
            e.currentTarget.style.transform="scale(1)";
          }}

          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: "2px",
            cursor: "pointer",
            padding: "3px 8px",
            borderRadius: "12px",
            transition: "0.2s ease",
          }}
        >

          <div
            className="bottomNavIcon"
            style={{
              fontSize: "20px",
            }}
          >
            {item.icon}
          </div>

          <span
            style={{
              fontSize: "11px",
              color:
                index === 0
                  ? "#4B2E83"
                  : "#6b7280",
              fontWeight:
                index === 0
                  ? "700"
                  : "500",
            }}
          >
            {item.name}
          </span>

        </div>

      </Link>

    )

  ))}

</div>

  </div>
   
   </div>

   {
showAlert && (

<div
  style={{
    position: "fixed",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    background:
      "rgba(15,23,42,0.35)",
    backdropFilter: "blur(6px)",
    WebkitBackdropFilter:
      "blur(6px)",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    zIndex: 999999,
    padding: "20px",
  }}
>

  <div
    style={{
      background:
        "rgba(255,255,255,0.78)",
      backdropFilter:
        "blur(20px)",
      WebkitBackdropFilter:
        "blur(20px)",
      border:
        "1px solid rgba(255,255,255,0.4)",
      width: "85%",
      maxWidth: "290px",
      borderRadius: "24px",
      padding: "22px",
      textAlign: "center",
      boxShadow:
        "0 8px 32px rgba(31,38,135,.18)",
      animation:
        "fadeIn .25s ease",
    }}
  >

    {/* ICONE */}

    <div
      style={{
        width: "58px",
        height: "58px",
        margin:
          "0 auto 12px",
        borderRadius: "50%",
        background:
          "rgba(108,43,217,.08)",
        display: "flex",
        justifyContent:
          "center",
        alignItems:
          "center",
      }}
    >

      <FaSearch
        style={{
          fontSize: "22px",
          color: "#5B21B6",
        }}
      />

    </div>

    {/* TITRE */}

    <h3
    translate="no"
      style={{
        color: "#111827",
        fontWeight: "800",
        fontSize: "18px",
        marginBottom: "8px",
      }}
    >
      KONAN SHOPPING
    </h3>

    {/* TEXTE */}

    <p
      style={{
        color: "#6B7280",
        lineHeight: "22px",
        fontSize: "13px",
        marginBottom: "18px",
      }}
    >
      Veuillez ajouter une image
      ou saisir un produit avant
      de lancer la recherche.
    </p>

    {/* BOUTON */}

    <button
      onClick={() =>
        setShowAlert(false)
      }
      style={{
        border: "none",
        width: "100%",
        height: "42px",
        borderRadius: "14px",
        background:
          "linear-gradient(135deg,#4B2E83,#7C3AED)",
        color: "#fff",
        fontWeight: "700",
        fontSize: "13px",
        cursor: "pointer",
        display: "flex",
        justifyContent:
          "center",
        alignItems:
          "center",
        gap: "8px",
        boxShadow:
          "0 10px 25px rgba(91,33,182,.25)",
      }}
    >

      <FaCheckCircle />

      D'ACCORD

    </button>

  </div>

</div>

)
}

{showWelcomePopup && (
  <div
    style={{
      position: "fixed",
      inset: 0,

      background: "rgba(15,23,42,.15)",

      backdropFilter: "blur(7px)",
      WebkitBackdropFilter: "blur(7px)",

      display: "flex",
      justifyContent: "center",
      alignItems: "center",

      padding: "16px",

      zIndex: 999999,
    }}
  >
    <div
      style={{
        width: "100%",
        maxWidth: "285px",

        padding: "18px 16px",

        borderRadius: "26px",

        position: "relative",

        overflow: "hidden",

        textAlign: "center",

       background: "rgba(255,255,255,.72)",

backdropFilter: "blur(45px)",

WebkitBackdropFilter: "blur(45px)",

border: "1px solid rgba(255,255,255,.65)",

boxShadow:
"0 18px 50px rgba(0,0,0,.16), inset 0 1px 1px rgba(255,255,255,.95)"
      }}
    >

      {/* REFLET HAUT */}

      <div
        style={{
          position: "absolute",
          top: "-55px",
          left: "-55px",

          width: "170px",
          height: "170px",

          borderRadius: "50%",

          background:
            "radial-gradient(circle,rgba(255,255,255,.35),transparent 72%)",

          filter: "blur(16px)",

          pointerEvents: "none",
        }}
      />

      {/* REFLET BAS */}

      <div
        style={{
          position: "absolute",
          bottom: "-60px",
          right: "-45px",

          width: "150px",
          height: "150px",

          borderRadius: "50%",

          background:
            "radial-gradient(circle,rgba(255,255,255,.18),transparent 72%)",

          filter: "blur(20px)",

          pointerEvents: "none",
        }}
      />

      {/* ICONE */}

      <div
        style={{
          width: "64px",
          height: "64px",

          margin: "0 auto",

          borderRadius: "50%",

          display: "flex",
          justifyContent: "center",
          alignItems: "center",

          background:
            "rgba(255,255,255,.22)",

          backdropFilter: "blur(18px)",

          border:
            "1px solid rgba(255,255,255,.35)",

          boxShadow:
            "inset 0 1px 1px rgba(255,255,255,.45)",
        }}
      >

        <FaCrown
          style={{
            fontSize: "28px",
            color: "#5B6CFF",
          }}
        />

      </div>

      {/* BADGE */}

      <div
        style={{
          display: "inline-flex",
          alignItems: "center",
          gap: "6px",

          marginTop: "14px",

          padding: "6px 13px",

          borderRadius: "50px",

          background:
            "rgba(255,255,255,.18)",

          backdropFilter: "blur(12px)",

          border:
            "1px solid rgba(255,255,255,.25)",

          color: "#5B6CFF",

          fontWeight: "800",

          fontSize: "10px",
        }}
      >

        <FaStar />

        OFFRE DE BIENVENUE

      </div>

      {/* TITRE */}

      <h2
        style={{
          marginTop: "14px",

          marginBottom: "14px",

          fontSize: "22px",

          fontWeight: "900",

          color: "#111827",

          whiteSpace: "nowrap",
        }}
      >

        Recevez{" "}

        <span
          style={{
            color: "#5B6CFF",

            textShadow:
              "0 2px 10px rgba(91,108,255,.25)",
          }}
        >
          5&nbsp;000&nbsp;FCFA
        </span>

      </h2>

      {/* DESCRIPTION */}

      <div
        style={{
          textAlign: "left",

          color: "#4B5563",

          fontSize: "13px",

          lineHeight: "20px",

          marginBottom: "18px",
        }}
      >

        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "10px",
            marginBottom: "10px",
          }}
        >

          <FaGem
            style={{
              color: "#5B6CFF",
              fontSize: "15px",
            }}
          />

          <span>
            Créez gratuitement votre compte.
          </span>

        </div>

        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "10px",
            marginBottom: "10px",
          }}
        >

          <FaCrown
            style={{
              color: "#5B6CFF",
              fontSize: "15px",
            }}
          />

          <span>
            Recevez un bonus de <b>5 000 FCFA.</b>
          </span>

        </div>

        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "10px",
          }}
        >

          <FaTruck
            style={{
              color: "#5B6CFF",
              fontSize: "15px",
            }}
          />

          <span>
            Livraison rapide partout au Cameroun.
          </span>

        </div>

      </div>

      {/* BOUTON PRINCIPAL */}

      <button
        onClick={() => {
          setShowWelcomePopup(false);
          navigate("/login");
        }}
        style={{
          width: "100%",
          height: "46px",

          border: "1px solid rgba(255,255,255,.28)",

          borderRadius: "16px",

          background:
            "linear-gradient(135deg,#5B6CFF,#6D28D9)",

          color: "#fff",

          fontWeight: "800",

          fontSize: "15px",

          cursor: "pointer",

          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          gap: "8px",

          boxShadow:
            "0 8px 24px rgba(91,108,255,.30)",
        }}
      >

        <FaUserPlus />

        Créer mon compte

      </button>

      {/* PLUS TARD */}

      <button
        onClick={() =>
          setShowWelcomePopup(false)
        }
        style={{
          width: "100%",

          height: "42px",

          marginTop: "10px",

          borderRadius: "16px",

          border:
            "1px solid rgba(255,255,255,.25)",

          background:
            "rgba(255,255,255,.12)",

          backdropFilter:
            "blur(20px)",

          WebkitBackdropFilter:
            "blur(20px)",

          color: "#374151",

          fontWeight: "700",

          fontSize: "14px",

          cursor: "pointer",

          boxShadow:
            "inset 0 1px 1px rgba(255,255,255,.35)",
        }}
      >
        Plus tard
      </button>

    </div>

  </div>

)}

{/* ================= FOOTER PREMIUM ================= */}

<div
  style={{
    marginTop: "30px",

    background: "#FFFFFF",

    borderTop: "1px solid #E5E7EB",

    borderRadius:
      window.innerWidth < 768
        ? "18px 18px 0 0"
        : "24px 24px 0 0",

    padding:
      window.innerWidth < 768
        ? "18px 14px"
        : "30px 28px",

    boxShadow:
      "0 -4px 20px rgba(0,0,0,.04)",
  }}
>

  {/* LOGO */}

  <div
    style={{
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      gap: "10px",
      marginBottom: "10px",
    }}
  >

    <img
      src="/logo.jpg"
      alt="Konan Shopping"

      style={{
        width:
          window.innerWidth < 768
            ? "34px"
            : "42px",

        height:
          window.innerWidth < 768
            ? "34px"
            : "42px",

        borderRadius: "10px",

        objectFit: "cover",

        boxShadow:
          "0 4px 12px rgba(0,0,0,.08)",
      }}
    />

    <h2
      translate="no"
      style={{
        margin: 0,

        fontSize:
          window.innerWidth < 768
            ? "17px"
            : "21px",

        fontWeight: "900",

        color: "#111827",
      }}
    >
      KONAN SHOPPING
    </h2>

  </div>

  {/* DESCRIPTION */}

  <p
    style={{
      textAlign: "center",

      color: "#6B7280",

      fontSize:
        window.innerWidth < 768
          ? "12px"
          : "13px",

      lineHeight: "20px",

      maxWidth: "500px",

      margin: "0 auto 18px auto",
    }}
  >
    Votre boutique en ligne de confiance au Cameroun.
    Paiement uniquement à la livraison, produits
    soigneusement sélectionnés et livraison rapide.
  </p>

  {/* ================= LIENS ================= */}
  
  <div
    style={{
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "wrap",
      gap: window.innerWidth < 768 ? "16px" : "28px",
      marginBottom: "20px",
    }}
  >
  
    <Link
      to="/privacy-policy"
      style={{
        display: "flex",
        alignItems: "center",
        gap: "6px",
        textDecoration: "none",
        color: "#4B2E83",
        fontWeight: "700",
        fontSize: window.innerWidth < 768 ? "12px" : "13px",
        whiteSpace: "nowrap",
        transition: ".25s",
      }}
    >
      <FaShieldAlt
        style={{
          fontSize: "15px",
        }}
      />
  
      Politique
    </Link>
  
    <Link
      to="/conditions"
      style={{
        display: "flex",
        alignItems: "center",
        gap: "6px",
        textDecoration: "none",
        color: "#4B2E83",
        fontWeight: "700",
        fontSize: window.innerWidth < 768 ? "12px" : "13px",
        whiteSpace: "nowrap",
        transition: ".25s",
      }}
    >
      <FaFileContract
        style={{
          fontSize: "15px",
        }}
      />
  
      Conditions
    </Link>
  
    <a
      href="https://wa.me/237694641329"
      target="_blank"
      rel="noreferrer"
      style={{
        display: "flex",
        alignItems: "center",
        gap: "6px",
        textDecoration: "none",
        color: "#16A34A",
        fontWeight: "700",
        fontSize: window.innerWidth < 768 ? "12px" : "13px",
        whiteSpace: "nowrap",
        transition: ".25s",
      }}
    >
      <FaWhatsapp
        style={{
          fontSize: "16px",
        }}
      />
  
      WhatsApp
    </a>
  
  </div>

  {/* AVANTAGES */}

  <div
    style={{
      display: "flex",

      flexWrap: "wrap",

      justifyContent: "center",

      gap:
        window.innerWidth < 768
          ? "12px"
          : "22px",

      marginBottom: "18px",
    }}
  >

    <div
      style={{
        display: "flex",

        alignItems: "center",

        gap: "6px",

        color: "#374151",

        fontWeight: "600",

        fontSize: "12px",
      }}
    >

      <FaTruck color="#4B2E83" />

      Livraison rapide

    </div>

    <div
      style={{
        display: "flex",

        alignItems: "center",

        gap: "6px",

        color: "#374151",

        fontWeight: "600",

        fontSize: "12px",
      }}
    >

      <FaLock color="#4B2E83" />

      Paiement sécurisé

    </div>

    <div
      style={{
        display: "flex",

        alignItems: "center",

        gap: "6px",

        color: "#374151",

        fontWeight: "600",

        fontSize: "12px",
      }}
    >

      <FaHeadset color="#4B2E83" />

      Assistance 7j/7

    </div>

  </div>

  {/* LIGNE */}

  <div
    style={{
      height: "1px",

      background: "#E5E7EB",

      marginBottom: "14px",
    }}
  />

  {/* COPYRIGHT */}

  <p
    style={{
      margin: 0,

      textAlign: "center",

      color: "#9CA3AF",

      fontSize: "11px",

      lineHeight: "18px",
    }}
  >
    © {new Date().getFullYear()}{" "}
    <b translate="no">
      KONAN SHOPPING CAMEROUN
    </b>

    <br />

    Tous droits réservés.
  </p>

</div>

<InstallButton />

</div>
</>
);

}

function App() {

  const [chatPosition, setChatPosition] =
    useState({
      x: window.innerWidth - 90,
      y: window.innerHeight - 160,
    });

 useEffect(() => {

  console.log("Effect 13");

  const currentPath =
    window.location.pathname;

  // =========================
  // BOT UNIQUEMENT SUR /
  // =========================

  const existingBot =
    document.querySelector(
      ".bpChatContainer"
    );

  if (existingBot) {

    existingBot.style.display =
      currentPath === "/"
        ? "block"
        : "none";

  }

  if (currentPath !== "/") {
    return;
  }

  // =========================
  // ÉVITER LE DOUBLE CHARGEMENT
  // =========================

  if (
    document.querySelector(
      'script[src*="botpress"]'
    )
  ) {
    return;
  }

  // =========================
  // CHARGEMENT BOTPRESS
  // =========================

  const script1 =
    document.createElement("script");

  script1.src =
    "https://cdn.botpress.cloud/webchat/v3.6/inject.js";

  script1.async = true;

  document.body.appendChild(
    script1
  );

  script1.onload = () => {

    const script2 =
      document.createElement("script");

    script2.src =
      "https://files.bpcontent.cloud/2025/01/25/16/20250125162805-WU2DYMW9.js";

    script2.defer = true;

    document.body.appendChild(
      script2
    );

    script2.onload = () => {

      const waitBot =
        setInterval(() => {

          const botpress =
            document.querySelector(
              ".bpChatContainer"
            );

          if (!botpress) return;

          clearInterval(
            waitBot
          );

          // =========================
          // POSITION PROFESSIONNELLE
          // =========================

          botpress.style.position =
            "fixed";

          botpress.style.zIndex =
            "99999";

          // MOBILE

          if (
            window.innerWidth < 768
          ) {

            botpress.style.bottom =
              "170px";

            botpress.style.right =
              "15px";

          } else {

            // PC

            botpress.style.bottom =
              "30px";

            botpress.style.right =
              "30px";

          }

          // =========================
          // ANIMATION
          // =========================

          botpress.style.opacity =
            "0";

          botpress.style.transition =
            "opacity .4s ease";

          setTimeout(() => {

            botpress.style.opacity =
              "1";

          }, 300);

          // =========================
          // EMPÊCHER DISPARITION
          // =========================

          const keepVisible = setInterval(() => {

  if (!document.body.contains(botpress)) {
    clearInterval(keepVisible);
    return;
  }

  botpress.style.display = "block";
  botpress.style.visibility = "visible";

}, 3000);

        }, 500);

    };

  };

}, []);

  return (


    <BrowserRouter>

<PageLoader />

      <Routes>

        <Route
          path="/"
          element={<Home />}
        />

        <Route
          path="/boutique"
          element={<Boutique />}
        />

        <Route
          path="/login"
          element={<UserLogin />}
        />

        <Route
          path="/admin-login"
          element={<Login />}
        />

        <Route
          path="/admin"
          element={
    <RequireAdmin>
      <Admin />
    </RequireAdmin>
  }
        />

        <Route
          path="/checkout"
          element={<Checkout />}
        />

        <Route
          path="/orders"
          element={
    <RequireAdmin>
      <Orders />
    </RequireAdmin>
  }
        />

        <Route
          path="/register"
          element={<Register />}
        />

        <Route
          path="/user-login"
          element={<UserLogin />}
        />

<Route
  path="/ai-mode"
  element={<AiMode />}
/>

<Route
  path="/favorites"
  element={
    <RequireUser>
      <Favorites />
    </RequireUser>
  }
/>

<Route
  path="/account"
  element={
    <RequireUser>
      <Account />
    </RequireUser>
  }
/>

<Route
  path="/product/:id"
  element={<ProductDetails />}
/>

<Route
  path="/success"
  element={<Success />}
/>

<Route
  path="/my-orders"
  element={
    <RequireUser>
      <MyOrders />
    </RequireUser>
  }
/>

<Route
  path="/coupons"
  element={<Coupons />}
/>

<Route
  path="/messages"
  element={
    <RequireUser>
      <Messages />
    </RequireUser>
  }
/>

<Route
  path="/orders/pending"
  element={
    <RequireUser>
      <PendingOrders />
    </RequireUser>
  }
/>

<Route
  path="/orders/shipped"
  element={
    <RequireUser>
      <ShippedOrders />
    </RequireUser>
  }
/>

<Route
  path="/orders/delivered"
  element={
    <RequireUser>
      <DeliveredOrders />
    </RequireUser>
  }
/>

<Route
  path="/orders/cancelled"
  element={
    <RequireUser>
      <CancelledOrders />
    </RequireUser>
  }
/>

<Route
  path="/order/:id"
  element={
    <RequireUserOrAdmin>
      <OrderDetails />
    </RequireUserOrAdmin>
  }
/>

<Route
  path="/track-order/:id"
  element={
    <RequireUserOrAdmin>
      <TrackOrder />
    </RequireUserOrAdmin>
  }
/>

<Route
  path="/driver/:id"
  element={
    <RequireDriver>
      <DriverTracking />
    </RequireDriver>
  }
/>

<Route
  path="/driver-register"
  element={
    <RequireAdmin>
      <DriverRegister />
    </RequireAdmin>
  }
/>

<Route
  path="/driver-login"
  element={
    <DriverLogin />
  }
/>

<Route
  path="/driver-dashboard"
  element={
    <RequireDriver>
      <DriverTracking />
    </RequireDriver>
  }/>

<Route
  path="/drivers"
  element={
    <RequireAdmin>
      <Drivers />
    </RequireAdmin>
  }
/>

<Route
  path="/admin-products"
  element={
    <RequireAdmin>
      <AdminProducts />
    </RequireAdmin>
  }
/>

<Route
  path="/admin-clients"
  element={
    <RequireAdmin>
      <AdminClients />
    </RequireAdmin>
  }
/>

<Route
  path="/admin-stats"
  element={
    <RequireAdmin>
      <AdminStats />
    </RequireAdmin>
  }
/>

<Route
  path="/admin-orders"
  element={
    <RequireAdmin>
      <AdminOrders />
    </RequireAdmin>
  }
/>

<Route
  path="/admin/settings"
  element={
    <RequireAdmin>
      <AdminSettings />
    </RequireAdmin>
  }
/>

<Route
  path="/admin-coupons"
  element={
    <RequireAdmin>
      <AdminCoupons />
    </RequireAdmin>
  }
/>

<Route
  path="/admin-social"
  element={
    <RequireAdmin>
      <AdminSocial />
    </RequireAdmin>
  }
/>

<Route
  path="/deliveries"
  element={
    <RequireAdmin>
      <Deliveries />
    </RequireAdmin>
  }
/>

<Route
  path="/forgot-password"
  element={<ForgotPassword />}
/>

<Route
  path="/reset-password/:token"
  element={
    <ResetPassword />
  }
/>

<Route
  path="/privacy-policy"
  element={<PrivacyPolicy />}
/>

<Route
  path="/conditions"
  element={<Conditions />}
/>

<Route path="/address" element={<Address />} />

<Route path="/promotions" element={<Promotions />} />

<Route
  path="/payment"
  element={<Paiement />}
/>

<Route path="/community" element={<Community />} />

<Route
  path="/message"
  element={<Message />}
/>

<Route
  path="/admin-messages"
  element={
    <RequireAdmin>
      <AdminMessages />
    </RequireAdmin>
  }
/>

      </Routes>

<ToastContainer
  position="top-right"
  autoClose={3000}
  hideProgressBar={false}
  newestOnTop
  closeOnClick
  rtl={false}
  pauseOnFocusLoss
  draggable
  pauseOnHover
  theme="light"
  toastClassName="konan-toast"
  bodyClassName="konan-toast-body"
/>

</BrowserRouter>

  );

}

const quickCard = {
  background: "white",

  borderRadius: "16px",

  padding: "16px 14px",

  boxShadow:
    "0 3px 10px rgba(0,0,0,0.04)",

  cursor: "pointer",

  transition: "0.3s",

  minHeight: "90px",

  border: "1px solid #f3f4f6",
};

const quickTitle = {
  margin: 0,

  fontSize: "13px",

  color: "#111827",

  lineHeight: "1.4",

  fontWeight: "700",
};

export default App;